# GaspardNZ — préparation publication mobile

Ce repo est déjà configuré pour iOS avec Capacitor. Ce kit ajoute la préparation Android et un workflow GitHub Actions pour générer les fichiers Android sans Play Console.

## Liens directs officiels

- Capacitor Android : https://capacitorjs.com/docs/android
- Capacitor iOS : https://capacitorjs.com/docs/ios
- Google Play Console : https://play.google.com/console/signup
- Aide officielle Play Console : https://support.google.com/googleplay/android-developer/answer/6112435
- Apple Developer Program : https://developer.apple.com/programs/enroll/
- App Store Connect : https://appstoreconnect.apple.com/

## État du projet

- App name : Gaspardnz
- App ID Capacitor : com.gaspardnz.app
- Web dir : dist
- Stack : Vite + React + Capacitor

## Android — préparation sans payer Google Play

Tu peux déjà générer un APK testable sans compte Google Play.

Après avoir ajouté les fichiers de ce kit dans le repo :

```bash
npm install
npm run build:app
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

Le fichier APK de test sera dans :

```txt
android/app/build/outputs/apk/debug/app-debug.apk
```

Tu peux l’installer manuellement sur un téléphone Android.

## Android — publication Google Play plus tard

Quand tu paieras le compte Google Play, il faudra :

1. Créer le compte développeur Google Play.
2. Créer l’application dans Play Console.
3. Générer un fichier AAB.
4. Signer l’AAB avec une clé de production.
5. Uploader l’AAB dans une piste de test interne.
6. Remplir la fiche Play Store : description, icône, captures, politique de confidentialité.
7. Passer en production après validation.

La commande AAB est :

```bash
cd android
./gradlew bundleRelease
```

Le fichier AAB sera dans :

```txt
android/app/build/outputs/bundle/release/app-release.aab
```

Attention : pour Google Play, l’AAB de production doit être signé proprement. Le workflow fourni génère surtout un APK de test et un AAB de base. La signature production se fera avec les secrets GitHub ou depuis Android Studio/Codemagic.

## iOS — plus tard

Ton projet contient déjà Capacitor iOS. Pour iOS, il faudra :

1. Compte Apple Developer.
2. Build cloud ou Mac récent avec Xcode.
3. Certificats/provisioning Apple.
4. Upload vers App Store Connect.
5. TestFlight.
6. Validation App Store.

## Commandes utiles

```bash
npm run build:app
npm run cap:sync
npm run cap:sync:android
npm run cap:sync:ios
npm run cap:open:android
npm run cap:open:ios
```
