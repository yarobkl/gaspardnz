# GaspardNZ — fiche Google Play provisoire

## Nom de l’application

Gaspardnz

## Nom court

Gaspardnz

## Description courte

Styliste, habilleur et maître de cérémonie à Paris.

## Description longue

GaspardNZ accompagne les hommes dans la création d’une allure forte, élégante et maîtrisée. L’application permet de découvrir son univers, ses prestations, ses looks, ses contenus et de prendre contact rapidement pour un mariage, un gala, une cérémonie ou un accompagnement personnalisé.

Services proposés :
- conseil en image masculin ;
- costumes et looks sur mesure ;
- accompagnement mariage et événements ;
- maître de cérémonie ;
- prise de contact rapide.

## Catégorie

Lifestyle / Mode / Shopping

## Données à préparer

- Icône 512 × 512
- Feature graphic 1024 × 500
- Captures d’écran téléphone
- Politique de confidentialité
- Adresse e-mail de contact
- URL officielle : https://gaspardnz.style/
