#!/usr/bin/env bash
set -euo pipefail

echo "Préparation mobile GaspardNZ..."

npm install
npm install @capacitor/android@^8.3.1

npm run build:app

if [ ! -d "android" ]; then
  npx cap add android
else
  npx cap sync android
fi

echo "Android Capacitor prêt."
echo "Pour générer un APK test : cd android && ./gradlew assembleDebug"
echo "Pour générer un AAB : cd android && ./gradlew bundleRelease"
